﻿var currentquestion = 0,
    score = 0,
    submt = true,
    picked;
var count = 0;

currentquestion = Math.floor(Math.random() * quiz.length);

function htmlEncode(value) {
    return $(document.createElement('div')).text(value).html();
}


function addChoices(choices) {
    if (typeof choices !== "undefined" && $.type(choices) == "array") {
        $('#choice-block').empty();
        for (var i = 0; i < choices.length; i++) {
            $(document.createElement('li')).addClass('choice choice-box').attr('data-index', i).text(choices[i]).appendTo('#choice-block');
        }
    }
}

function nextQuestion() {
    submt = true;
    $('#explanation').empty();
    $('#question').text(quiz[currentquestion]['question']);
    $('#pager').text('Question ' + Number(currentquestion + 1) + ' of ' + quiz.length);
    if (quiz[currentquestion].hasOwnProperty('image') && quiz[currentquestion]['image'] != "") {
        if ($('#question-image').length == 0) {
            $(document.createElement('img')).addClass('question-image').attr('id', 'question-image').attr('src', quiz[currentquestion]['image']).attr('alt', htmlEncode(quiz[currentquestion]['question'])).insertAfter('#question');
        }
        else {
            $('#question-image').attr('src', quiz[currentquestion]['image']).attr('alt', htmlEncode(quiz[currentquestion]['question']));

        }
    } else {
        $('#question-image').remove();
    }
    addChoices(quiz[currentquestion]['choices']);
    setupButtons();


}


function processQuestion(choice) {

    if ((quiz[currentquestion]['choices'])[choice] == quiz[currentquestion]['correct']) {
        $('.choice').eq(choice).css({
            'background-color': '#50D943'
        });
        
        $('#explanation').html('<strong>Correct!</strong> ' + htmlEncode(quiz[currentquestion]['explanation']));
        //  $('#image').html(htmlEncode(quiz[currentquestion]['uimage']));
        score++;

    } else {
        $('.choice').eq(choice).css({
            'background-color': '#D92623'
        });

        $('#explanation').html('<strong>Incorrect.</strong> ' + htmlEncode(quiz[currentquestion]['explanation']));
        

    }

    $('#question-image').attr('src', quiz[currentquestion]['uimage']).attr('alt', htmlEncode(quiz[currentquestion]['question']));

    currentquestion = Math.floor(Math.random() * quiz.length);
    count++;

    $('#submitbutton').html('NEXT QUESTION &raquo;').on('click', function () {
        if (count == quiz.length) {
            endQuiz();
        } else {
            $(this).text('Check Answer').css({
                'color': '#222'
            }).off('click');
            
            nextQuestion();
            
        }
    })

}


function setupButtons() {
    $('.choice').on('mouseover', function () {
        $(this).css({
            'background-color': '#e1e1e1'
        });
    });
    $('.choice').on('mouseout', function () {
        $(this).css({
            'background-color': '#fff'
        });
    })
    $('.choice').on('click', function () {
        picked = $(this).attr('data-index');
        $('.choice').removeAttr('style').off('mouseout mouseover');
        $(this).css({
            'border-color': '#222',
            'font-weight': 700,
            'background-color': '#c1c1c1'
        });
        if (submt) {
            submt = false;
            $('#submitbutton').css({
                'color': '#000'
            }).on('click', function () {
                $('.choice').off('click');
                $(this).off('click');
                processQuestion(picked);
            });
        }
    })
}


function endQuiz() {
    stopme();
    $('#explanation').empty();

    $('#question').empty();

    $('#choice-block').hide();

    $('#submitbutton').hide();

    $('#question-image').hide();

    $('#start').hide();

    $("#tx").hide();

    $('#question').text("SCORE:" + Math.round(score * 2));

    //document.getElementById("explanation").innerHTML = '<font size="5" color="#cc6500"><b><a href="tollywood.html" style ="text-decoration:none;"><span class="glyphicon glyphicon-repeat"></span> Play Again</a>&nbsp&nbsp<a href="categories.html" style ="text-decoration:none;"><span class="glyphicon glyphicon-home"></span> Home</a></b></font>';
    document.getElementById("explanation").innerHTML = '<font size="5"><b><a href="categories.html" style ="text-decoration:none;">Next <span class="glyphicon glyphicon-circle-arrow-right"></span></a></b></font>';

}


function init() {

    //add pager and questions
    if (typeof quiz !== "undefined" && $.type(quiz) === "array") {

        //add first question
        $(document.createElement('h2')).addClass('question').attr('id', 'question').text(quiz[currentquestion]['question']).appendTo('#frame');
        //add image if present
        if (quiz[currentquestion].hasOwnProperty('image') && quiz[currentquestion]['image'] != "") {
            $(document.createElement('img')).addClass('question-image').attr('id', 'question-image').attr('src', quiz[currentquestion]['image']).attr('alt', htmlEncode(quiz[currentquestion]['question'])).appendTo('#frame');
        }

        $(document.createElement('p')).addClass('explanation').attr('id', 'explanation').html('&nbsp;').appendTo('#frame');

        //questions holder
        $(document.createElement('ul')).attr('id', 'choice-block').appendTo('#frame');

        //add choices
        addChoices(quiz[currentquestion]['choices']);

        //add submit button
        $(document.createElement('div')).addClass('choice-box').attr('id', 'submitbutton').text('Check Answer').css({
            'font-weight': 700,
            'color': '#222',
            'padding': '30px 0'

        }).appendTo('#frame');

        setupButtons();
    }
}

init();


