﻿var quiz = [
       {
           "question": "",
           "image":"http://res.cloudinary.com/bhavya/image/upload/v1458979465/AdamLambertB_m3jn19.jpg",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/AdamLambert_efmyci.jpg",
           "choices": [
                                   "Johnny Depp",
                                   "Al Pacino",
                                   "Adam Lambert",
                                   "Robert De Niro"
           ],
           "correct": "Adam Lambert",
           "explanation": "Adam Mitchel Lambert born January 29, 1982.He is an American singer, songwriter and stage actor. Since 2009, he has sold over 2.5 million albums and 5 million singles worldwide.",
       },
       {
           "question": "",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979464/AngelinaJolieB_ekehdp.jpg",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/AngelinaJolieO_apqh8p.jpg",
           "choices": [
                                   "Charlize Theron",
                                   "Angelina Jolie",
                                   "Kate Winslet",
                                   "Keira Knightley"
           ],
           "correct": "Angelina Jolie",
           "explanation": "Angelina Jolie Pitt born on June 4, 1975 is an American actress, filmmaker, and humanitarian. She has received an Academy Award, two Screen Actors Guild Awards, and three Golden Globe Awards.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/BonnieWrightO_kvrd4p.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/BonnieWrightB_zmxs1c.jpg",
           "choices": [
                                   "Bonnie Wright",
                                   "Cameron Diaz",
                                   "Nicole Kidman",
                                   "Sandra Bullock"
           ],
           "correct": "Bonnie Wright",
           "explanation": "Bonnie Francesca Wright born on 17 February 1991 is an English actress and model. She is best known for playing the role of Ginny Weasley in the Harry Potter film series.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/CamGigandetO_lqppxs.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/CamGigandetB_iu1cgd.jpg",
           "choices": [
                                   "Keanu Reeves",
                                   "Nicolas Cage",
                                   "Simon Baker",
                                   "Cam Gigandet"
           ],
           "correct": "Cam Gigandet",
           "explanation": "Cam Joslin Gigandet born on August 16, 1982 is an American actor and appearances in feature films Twilight, Pandorum, Never Back Down, Burlesque, Easy A, The Roommate and Priest.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/ClintBartonO_lgma53.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/ClintBartonB_k3aov6.jpg",
           "choices": [
                                   "Clint Barton",
                                   "Brad Pitt",
                                   "John Travolta",
                                   "Guy Pearce"
           ],
           "correct": "Clint Barton",
           "explanation": "Hawkeye (Clint Barton) is a fictional superhero appearing in American comic books published by Marvel Comics.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/EmmaWatsonO_hizlwj.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/EmmaWatsonB_ocnc7w.jpg",
           "choices": [
                                   "Sandra Bullock",
                                   "Emma watson",
                                   "Scarlett Johansson",
                                   "Charlize Theron	"
           ],
           "correct": "Emma watson",
           "explanation": "Emma Charlotte Duerre Watson born on 15 April 1990 is a British actress, model, and activist.She rose to prominence after landing her first professional acting role as Hermione Granger in the Harry Potter film series.",
       },
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/EvaGreenO_xzq0ir.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/EvaGreenB_ckwk6q.jpg",
	    "choices": [
                                "Angelina Jolie",
                                "Sandra Bullock",
                                "Eva Green",
                                "Megan Fox"
	    ],
	    "correct": "Eva Green",
	    "explanation": "Eva Gaëlle Green born 6 July 1980 is a French actress. She started her career in theatre before making her film debut in 2003 in Bernardo Bertolucci's controversial The Dreamers.",
	},
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/GeneKellyO_omcujh.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/GeneKellyB_kv3f1q.jpg",
	    "choices": [
                                "Morgan Freeman",
                                "Keanu Reeves",
                                "Gene Kelly",
                                "Nicolas Cage"
	    ],
	    "correct": "Gene Kelly",
	    "explanation": "Eugene Curran Gene Kelly (August 23, 1912 – February 2, 1996) was an American-Irish dancer, actor, singer, film director, producer and choreographer.",
},
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/JustinTimberlakeO_uhrbu2.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/JustinTimberlakeB_poatnx.jpg",
	    "choices": [
                                "Justin Timberlake",
                                "Simon Baker",
                                "Orlando Bloom",
                                "Brad Pitt"
	    ],
	    "correct": "Justin Timberlake",
	    "explanation": "Justin Randall Timberlake (born January 31, 1981) is an American singer, songwriter, actor, and record producer. He appeared on the television shows Star Search and The All-New Mickey Mouse Club as a child.",
	},
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979482/oliviaWildeO_cidlhl.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/oliviaWildeB_vimkhx.jpg",
	    "choices": [
                                "Nicole Kidman",
                                "Kate Winslet",
                                "Megan Fox",
                                "Olivia Wilde"
	    ],
	    "correct": "Olivia Wilde",
	    "explanation": "Olivia Wilde born March 10, 1984 is an American actress, model, producer and activist.She is well known for her television role as Dr. Remy Thirteen Hadley on House,Legacy,Cowboys & Aliens,Her,Drinking Buddies and Rush. ",
},

	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979483/PaulinaGaitanO_pulyny.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979465/PaulinaGaitanB_fkwnex.jpg",
	    "choices": [
                                "Paulina Gaitan",
                                "Katherine Heigl",
                                "Scarlett Johansson",
                                "Kate Winslet"
	    ],
	    "correct": "Paulina Gaitan",
	    "explanation": "Paulina Gaitan was born in Mexico City, Distrito Federal.Gaitán started acting at age 9 and at the age of 12 had an important role in Mexican director Luis Mandoki's Innocent Voices, a tale about the civil war in El Salvador.",
	},

	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979483/RobertDowneyO_dt5vew.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979466/RobertDowneyB_qtqttq.jpg",
	    "choices": [
                                "Guy Pearce",
                                "Morgan Freeman",
                                "John Travolta",
                                "Robert Downey"
	    ],
	    "correct": "Robert Downey",
	    "explanation": "Robert John Downey Jr. born April 4, 1965 is an American actor. His career has included critical and popular success in his youth, followed by a period of substance abuse and legal troubles in middle age.",
},

	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979483/StevenSeagalO_o4boqu.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979466/StevenSeagalB_mgdkcz.jpg",
	    "choices": [
                                "Arnold Schwarzenegger",
                                "Russell Crowe",
                                "Steven Seagal",
                                "Morgan Freeman"
	    ],
	    "correct": "Steven Seagal",
	    "explanation": "Steven Frederic Seagal born April 10, 1952 is an American actor, film producer, screenwriter, film director, martial artist, Aikido instructor, musician, reserve deputy sheriff and entrepreneur.",
	},
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979483/TomCruiseO_wkcmdt.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979466/TomCruiseB_spghi4.jpg",
	    "choices": [
                                "Johnny Depp",
                                "Christian Bale",
                                "Simon Baker",
                                "Thomas Mapother"
	    ],
	    "correct": "Thomas Mapother",
	    "explanation": "Tom Cruise born on July 3, 1962 is an American actor and filmmaker. Cruise has been nominated for three Academy Awards and has won three Golden Globe Awards.",
	},
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979483/TobeyMaguireO_fht6xo.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979466/TobeyMaguireB_provjf.jpg",
	    "choices": [
                                "Tobey Maguire",
                                "Morgan Freeman",
                                "John Travolta",
                                "Keanu Reeves"
	    ],
	    "correct": "Tobey Maguire",
	    "explanation": "Tobias Vincent Tobey Maguire born on June 27, 1975 is an American actor and film producer who began his career in the late 1980s.",
},
	{
	    "question": "",
	    "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1458979483/VinDieselO_ugzmsh.jpg",
	    "image": "http://res.cloudinary.com/bhavya/image/upload/v1458979466/VinDieselB_hzos4f.jpg",
	    "choices": [
                                "Simon Baker",
                                "Morgan Freeman",
                                "Arnold Schwarzenegger",
                                "Vin Diesel"
	    ],
	    "correct": "Vin Diesel",
	    "explanation": "Mark Sinclair born on July 18, 1967, better known by his stage name Vin Diesel, is an American actor, producer, director, and screenwriter. He is best known for his portrayals of Dominic Toretto in The Fast and the Furious film series",
	},
];