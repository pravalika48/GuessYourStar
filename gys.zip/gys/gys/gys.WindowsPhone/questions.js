﻿var quiz = [
       {
           "question": "",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029672/suryab_i9rwop.jpg",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029806/suryao_htohph.jpg",
           "choices": [
                                   "Kaarthi",
                                   "Suriya",
                                   "Sudheer babu",
                                   "Nithin"
           ],
           "correct": "Suriya",
           "explanation": "Suriya (born Saravanan Sivakumar on 23 July 1975) is an Indian film actor, producer, philanthropist and television presenter.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029731/bhumikao_uvxm8v.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029563/bhumikab_x1vmwz.jpg",
           "choices": [
                                   "charmi",
                                   "Anushka",
                                   "Bhumika Chawla",
                                   "Meena"
           ],
           "correct": "Bhumika Chawla",
           "explanation": "Bhumika Chawla born in a Punjabi family in New Delhi on 21 August,1978.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029777/prabhaso_stvclr.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029643/prabhasb_tyatit.jpg",
           "choices": [
                                   "Prabhas",
                                   "Rana",
                                   "Allu Arjun",
                                   "Naga Chaithanya"
           ],
           "correct": "Prabhas",
           "explanation": "Prabhas (born Prabhas Raju Uppalapati) is an Indian film actor who works in Telugu cinema. Prabhas is the nephew of Telugu actor Uppalapati Krishnam Raju. Prabhas made his film debut with the 2002 drama film, Eshwar.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029722/amalapaulo_to7lij.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029555/amalpaulb_fniho5.jpg",
           "choices": [
                                   "Kajal",
                                   "Amala Paul",
                                   "Rejina",
                                   "Shanvi"
           ],
           "correct": "Amala Paul",
           "explanation": "Amala was born in a Christian family on 26 October 1991 in Ernakulam, Kerala to Paul Varghese and Annice Paul.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029793/ramcharano_uuefan.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029660/ramcharanb_orv5uf.jpg",
           "choices": [
                                   "Prabhas",
                                   "Ram Charan",
                                   "Naga Chaithanya",
                                   "Allu arjun"
           ],
           "correct": "Ram Charan",
           "explanation": "Ram Charan is an Indian film actor, dancer, producer, businessman and entrepreneur, who works in Telugu cinema.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029736/geneliao_jegcil.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029567/geneliab_v0ms2k.jpg",
           "choices": [
                                   "Genelia",
                                   "richa",
                                   "Rakul Preeth Singh",
                                   "Nisha Agarval"
           ],
           "correct": "Genelia",
           "explanation": "Genelia D'Souza born 5 August 1987 is an Indian film actress, model, and host.Born in Mumbai into a Mangalorean Catholic family.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029750/kamalo_scq6gj.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029610/kamalb_mzmsxp.jpg",
           "choices": [
                                   "Balakrishna",
                                   "Kamal Haasan",
                                   "Jagapathi Babu",
                                   "Rajashekar"
           ],
           "correct": "Kamal Haasan",
           "explanation": "Kamal Haasan (born 7 November 1954) is an Indian film actor, screenwriter, director, producer, playback singer, choreographer, lyricist, philanthropist and dancer who works primarily in the Tamil film industry.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029784/priyaanando_jbl1rc.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029651/priyaanandb_vjhesq.jpg",
           "choices": [
                                   "Amala paul",
                                   "pooja Hegde",
                                   "Priya Anand",
                                   "Thamannah"
           ],
           "correct": "Priya Anand",
           "explanation": "Anand was born in Chennai, Tamil Nadu as the only child to Radha and Bharadwaj Anand on 17 September,1986.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029726/anjalio_lpt7cz.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029559/anjalib_tgnook.jpg",
           "choices": [
                                   "Anushka",
                                   "Samantha",
                                   "Priya Mani",
                                   "Anjali"
           ],
           "correct": "Anjali",
           "explanation": "Anjali is an Indian film actress and model, who predominantly appears in Tamil and Telugu films.Born in Razole, East Godavari District, Andhra Pradesh on 16 June,1986.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029770/navdeepo_ijappq.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029636/navdeepb_a5mc8s.jpg",
           "choices": [
                                   "Navdeep",
                                   "Nithin",
                                   "Sundeep kishan",
                                   "Tharun"
           ],
           "correct": "Navdeep",
           "explanation": "Navdeep Pallapolu is a South Indian actor, born on January 26, 1986.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029746/kajalo_hb703s.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029575/kajalb_vmgdbm.jpg",
           "choices": [
                                   "Nisha",
                                   "parvathi melton",
                                   "Kajal",
                                   "pranitha"
           ],
           "correct": "Kajal",
           "explanation": "Kajal Aggarwal is an Indian film actress and model. Born on June 19, 1985 who Primarily known for her work in Telugu and Tamil films.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029815/tamanao_gcyunb.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029681/tamanab_wd8fvp.jpg",
           "choices": [
                                   "Rakul preeth Singh",
                                   "Thamannaah",
                                   "Lavanya tripati",
                                   "Rashi Khannah"
           ],
           "correct": "Thamannaah",
           "explanation": "Tamannaah Bhatia is an Indian actress, born on December 21, 1989 who predominantly appears in Telugu and Tamil films.",
       },

];
