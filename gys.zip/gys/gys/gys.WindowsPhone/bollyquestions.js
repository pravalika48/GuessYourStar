﻿var quiz = [
       {
           "question": "",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029314/aishwaryaraib_u2ymze.jpg",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029429/aishwaryaraio_trqd8t.jpg",
           "choices": [
                                   "Kriti sanan",
                                   "Aishwarya Rai",
                                   "Kareena kapoor",
                                   "Sameera Reddy"
           ],
           "correct": "Aishwarya Rai",
           "explanation": "Aishwarya Rai Bachchan born 1 November 1973 , is an Indian actress, former model and the winner of the Miss World pageant of 1994.",
       },
       {
           "question": "",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029334/bigbb_lj7uf8.jpg",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029444/bigbo_qebt4h.jpg",
           "choices": [
                                   "Amitabh Bachan",
                                   "Salman Khan",
                                   "Jackie Schroff",
                                   "Mohnish Behl"
           ],
           "correct": "Amitabh Bachan",
           "explanation": "Amitabh Harivansh Bachchan born 11 October 1942.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029434/Aliabhatto_vmxrvn.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029321/Aliabhattb_nrzmo5.jpg",
           "choices": [
                                   "Nargis Fakhri",
                                   "Alia Bhatt",
                                   "Yami Gautham",
                                   "Vaani Kapoor"
           ],
           "correct": "Alia Bhatt",
           "explanation": "Alia Bhatt born 15 March 1993 is an Indian actress who appears in Bollywood films",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029465/deepikapadukoneo_jhyqkr.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029339/deepikapadukoneb_vsef5e.jpg",
           "choices": [
                                   "Diana Penty",
                                   "Shraddha Kapoor",
                                   "Deepika Padukone",
                                   "Kriti Sanon"
           ],
           "correct": "Deepika Padukone",
           "explanation": "Deepika Padukone born 5 January 1986 is an Indian film actress and model.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029439/amirkhano_bm7u8v.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029327/amirkhanb_ydmsgx.jpg",
           "choices": [
                                   "Vivek Oberoi",
                                   "Sharman Joshi",
                                   "Jimmy Shergil",
                                   "Aamir Khan"
           ],
           "correct": "Aamir Khan",
           "explanation": "Aamir Khan born Mohammed Aamir Hussain Khan on 14 March 1965 is an Indian film actor, director and producer.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029469/Hrithikroshano_kxnjld.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029345/Hrithikroshanb_cihssg.jpg",
           "choices": [
                                   "Sidharth Malhotra",
                                   "Hrithik Roshan",
                                   "John Abraham",
                                   "Ajay Devghan"
           ],
           "correct": "Hrithik Roshan",
           "explanation": "Hrithik Roshan born 10 January 1974 is an Indian film actor. He has established a successful career in Bollywood, has won six Filmfare Awards.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029475/Imrankhano_xkerqb.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029350/Imrankhanb_dy4ykc.jpg",
           "choices": [
                                   "Imran Khan",
                                   "Aditya Rai Kapoor",
                                   "Farhan Akthar",
                                   "John Abraham"
           ],
           "correct": "Imran Khan",
           "explanation": "Imran Khan born Imran Pal 13 January 1983 is an Indian American actor, who appears in Hindi films. He is the nephew of actor Aamir Khan and director-producer Mansoor Khan, and the grandson of director-producer Nasir Hussain.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029481/Parineetichoprao_etp8yh.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029356/Parineetichoprab_bjieqb.jpg",
           "choices": [
                                   "Gayatri Joshi",
                                   "Parineeti Chopra",
                                   "Neha Sharma",
                                   "Amy Jackson"
           ],
           "correct": "Parineeti Chopra",
           "explanation": "Parineeti Chopra born 22 October 1988 is an Indian actress who appears in Hindi films. She has received several awards and nominations, including a Filmfare and National Film Award",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029485/priyankachoprao_feswbx.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029363/priyankachoprab_jhotg0.jpg",
           "choices": [
                                   "Jacqueline Fernandez",
                                   "Priyanka Chopra",
                                   "Katrina Kaif",
                                   "Anushka Sharma"
           ],
           "correct": "Priyanka Chopra",
           "explanation": "Priyanka Chopra born 18 July 1982 is an Indian film actress and singer, and the winner of the Miss World pageant of 2000.",
       },
       {
           "question": "",
           "uimage": "http://res.cloudinary.com/bhavya/image/upload/v1457029490/Ranbirkapooro_bwggon.jpg",
           "image": "http://res.cloudinary.com/bhavya/image/upload/v1457029371/Ranbirkapoorb_bzceft.jpg",
           "choices": [
                                   "Karan Singh Grover",
                                   "Ranbir Kapoor",
                                   "Aditya Roy Kapur",
                                   "Sidharth Malhotra"
           ],
           "correct": "Ranbir Kapoor",
           "explanation": "Ranbir Kapoor born 28 September 1982 is an Indian actor. Through his career in Bollywood films, he has become one of the highest-paid actors and popular celebrities in India",
       },


];









